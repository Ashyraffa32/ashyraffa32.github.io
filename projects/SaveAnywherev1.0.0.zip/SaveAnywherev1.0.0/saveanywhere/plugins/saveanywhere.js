(function() {
    // ==========================================
    // HOOK 1: Membuka Kunci Tombol Save di Menu
    // ==========================================
    const _Window_MenuCommand_makeCommandList = Window_MenuCommand.prototype.makeCommandList;
    Window_MenuCommand.prototype.makeCommandList = function() {
        // Jalankan fungsi bawaan game terlebih dahulu agar menu lain tetap muncul
        _Window_MenuCommand_makeCommandList.call(this); 
        
        // Cek apakah tombol save sudah ada, jika belum, paksa tambahkan ke list menu
        if (!this._commandWindow || !this._commandWindow.findSymbol('save')) {
            this.addSaveCommand();
        }
    };

    // Menyisipkan logika penentu apakah tombol save bisa diklik atau abu-abu (disable)
    Window_MenuCommand.prototype.isSaveEnabled = function() {
        // Secara default OMORI mengunci ini berdasarkan piknik Mari. 
        // Kita bypass menjadi true agar SELALU bisa diklik saat menu dibuka.
        return true; 
    };

    // ==========================================
    // HOOK 2: Memberi Fungsi Saat Tombol Diklik
    // ==========================================
    const _Scene_Menu_createCommandWindow = Scene_Menu.prototype.createCommandWindow;
    Scene_Menu.prototype.createCommandWindow = function() {
        _Scene_Menu_createCommandWindow.call(this);
        
        // Daftarkan handler 'save' ke fungsi commandSave bawaan game di rpg_scenes.js
        this._commandWindow.setHandler('save', this.commandSave.bind(this));
    };
})();
